# 记忆与检索

负责：短期上下文窗口、噪声判定、摘要触发与模板、FTS5 检索策略。
上游：`docs/requirements.md` F3；表结构见 `docs/database.md`。
改动影响：窗口/阈值/模板变更会影响 `docs/token.md` 的成本结论。

## 1. 原则

**原文存储 ≠ 模型上下文。** 数据库可以保存一切，进入模型上下文的必须是有用的那部分。
检索是**补充背景**，不替代短期原文。

## 2. 短期窗口（ContextBuilder）

| 情形 | 默认条数 | 说明 |
|---|---|---|
| 普通问题 | 20 | 包含 Bot 自己的发言，按时间升序；实现见 `app/session/context.py` 的 `window_size()` |
| 复杂问题 | 最多 50 | 触发条件：出现长文本、代码块、或用户明确追问上文 |
| 纯闲聊 | 10 | 只保证不"失忆"，不追求连续性 |
| 硬约束 | 约 6000 字符（`HISTORY_BUDGET_CHARS`，字符近似，不引入 tokenizer） | 超预算从最旧的消息开始丢；本轮用户消息永不丢（`ContextBuilder._trim` 保留本轮 `message_id` 集合，即使本轮自身超预算也不裁，见 `TODO.md` T3）；被裁条数可用 `ContextBuilder.consume_trimmed()` 观测 |

- **模式优先**：`chat_settings.mode` 为 economy / smart / unrestricted 时窗口固定为 10 / 50 / 50，**不再走上面的意图分档**；只有 normal（默认）用上表的三档（`docs/token.md` §5）。
- 窗口按 `chat_id`（未来 `thread_id`）过滤，绝不跨群（`messages.recent()` 已排除 `noise=1`）。
  `thread_id` 是**预留**：schema 有列、`messages.recent()` 支持该参数，但当前没有调用方传入，摘要、游标与 FTS 检索都是 chat 级（阶段 8 再做论坛主题隔离）。
- **本轮边界**：窗口只取「处理这一轮时已入库」的消息（`id` 快照）；模型调用期间新到的消息留在库里，合并进下一轮。
- **私聊**：私聊消息默认不写入 `messages`，因此不进入任何上下文（见 `docs/requirements.md` §2.2）。
- 被丢掉的旧消息不影响已落库数据；需要时靠摘要与检索找回。

## 3. 噪声（noise）判定

入库时打标，用于决定"是否进入模型上下文"，不影响存储：

- 标记为噪声：纯表情、纯标点、长度 < 4 且无疑问词、常见无信息量短句（如"哈哈/草/666/笑死/确实/晚安"）。实现：`app/session/noise.py` 的 `is_noise()`，在 `runner.handle` 入库时判定并写入 `messages.noise`。
- 永不标为噪声：包含 `@`、问号、链接、代码块、报错关键词、或回复了 Bot 的消息。
- 噪声消息仍写入 `messages`（`noise=1`），但默认不进入上下文；若它是本轮待处理消息则不参与触发。

## 4. 摘要

触发条件（任一满足，异步执行，不阻塞回复）：

- 自上次摘要以来新增消息 ≥ `SUMMARY_MIN_MESSAGES`（默认 40）条；
- 自上次摘要以来新增字符 ≥ `HISTORY_BUDGET_CHARS`（默认 6000）**且**消息数 ≥ `10`（避免长消息连发把摘要打成碎片）；
- 群内静默 ≥ `SUMMARY_QUIET_SECONDS`（默认 120 秒）且期间有新消息（`SummaryService` 默认时钟为 `time.time`，与库内 `created_at` 同为 Unix 秒；`app/main.py` 不再注入时钟）。

固定模板（模型只填空，不自由发挥）：

```
当前话题：
正在做的事：
已完成：
待完成：
偏好/约束：
关键实体（人名、项目名、文件）：
```

- 每个 `chat_id` 保留最近 1 条滚动摘要 + 历史摘要归档（每群保留最近 50 条，**已实现** `SUMMARY_KEEP=50`，写成功后立即 prune）；只把最近的摘要放入上下文。
- 实现：`app/session/summary.py` 的 `SummaryService`（per-chat 锁、滚动输入=上次摘要+游标之后的消息、`msg_to` 作游标）与 `SummaryScheduler`（后台循环，`SUMMARY_POLL_SECONDS`）；失败不写库、不推进游标，重启后按游标续跑；摘要调用单独记 `usage.purpose='summary'`。
- 摘要必须短（默认 ≤300 字）；超出即重新压缩，不得逐条罗列消息。

## 5. 检索（FTS5）

流程：查询构造 → FTS 搜索（摘要 + 笔记）→ 去重 → 排序 → 预算内注入。

- 检索源：`summaries`、`notes`（不含全部原文，避免把旧消息重新灌回上下文）。
- 查询由当前用户消息的关键词构成（`app/session/retrieval.py` 的 `term_tokens()`：中文双字 bigram + 拉丁词）；不额外调用模型生成检索词（省 token）。
- 触发条件：出现回溯/指代信号词（之前/上次/刚才/那个/继续/接着/前面…），或短期窗口被预算裁剪且仍有未摘要历史；否则不检索。
- 检索只查 `summaries`/`notes` 的 FTS（`tokens` 列），SQL 强制带 `chat_id`：跨群召回属于缺陷。
- 注入上限：最多 3 条、总计 ≤800 字符；注入位置在动态段（见 `docs/token.md` §3）。
- 命中结果必须带来源（摘要 id / 笔记名），便于模型区分"记忆"与"当前对话"。

## 6. 笔记（notes）

- 长期事实（群规、偏好、项目状态）由**群主**通过 `/note` 写入 `notes`（**已实现**，阶段 8 批处理里程碑 B）。
  模型侧仍没有写笔记的工具（模型不能自己"记住"东西）；运维脚本 `scripts/register_note.py` 保留给迁移与应急写入。
- `/note` 语法（只认群主，普通管理员与成员按固定拒绝文案处理）：
  `/note`（列出全部：只回名称、版本、字数、更新时间，不复读正文）、`/note <名称>`（查看正文）、
  `/note <名称> <内容>`（写入或同名覆盖，`version` +1）、`/note del <名称>`（删除，同步清 `notes_fts`）。
  实现：解析与文案 `app/ops/notes.py`（纯文本、无数据库），授权与读写 `app/ops/commands.py` 的 `_note()`，
  单行化复用 `app/ops/text.py`。
- 每条笔记 ≤500 字（单行化后）；笔记名 ≤50 字符。上限在命令层（`app/ops/notes.py`）与运维脚本里各校验一次，
  `app/storage/repo/notes.py` 层不做长度校验：绕过命令直接写库的长度由调用方负责。
- 写入/删除失败只回一句固定短句；确认文案只含名称、版本与字数，**不回显正文**（与人设 `persona_override` 同一口径）。
- 笔记是 FTS 的检索源之一；不默认全量注入上下文。
